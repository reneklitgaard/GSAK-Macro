@echo off
setlocal
set GSAK_MACROS=%APPDATA%\GSAK\macros
echo ================================================
echo  GC Makroer - Installation
echo ================================================
echo.
if not exist "%GSAK_MACROS%" ( mkdir "%GSAK_MACROS%" & echo Oprettede: %GSAK_MACROS% )
if not exist "C:\pqfiler"     ( mkdir "C:\pqfiler"     & echo Oprettede: C:\pqfiler )
echo.
copy /Y "GC_Menu.gsk"       "%GSAK_MACROS%\GC_Menu.gsk"       >nul && echo OK: GC_Menu.gsk
copy /Y "streak-filter.gsk" "%GSAK_MACROS%\streak-filter.gsk" >nul && echo OK: streak-filter.gsk
copy /Y "cx-filter.gsk"     "%GSAK_MACROS%\cx-filter.gsk"     >nul && echo OK: cx-filter.gsk
copy /Y "GC_Logo.png"       "%GSAK_MACROS%\GC_Logo.png"       >nul && echo OK: GC_Logo.png
echo.
echo GetPQ.ps1 oprettes automatisk foerste gang du bruger Hent PQ.
echo.
echo ================================================
echo  Installation faerdig!
echo  Aaben GSAK og koer GC_Menu.gsk
echo ================================================
echo.
pause
